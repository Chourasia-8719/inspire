<?php

use Illuminate\Support\Facades\Route;

///////////////////////            Routes For User View                ///////////////////////////////////

Route::get('/',[\App\Http\Controllers\User\HomeController::class, 'index'])->name('user.home');

Route::get('/about',[\App\Http\Controllers\User\HomeController::class, 'about_us'])->name('user.about');

Route::get('/courses',[\App\Http\Controllers\User\HomeController::class, 'courses'])->name('user.course');

Route::get('/contact-us',[\App\Http\Controllers\User\HomeController::class, 'contact_us'])->name('user.contact');

Route::post('/contact-us',[\App\Http\Controllers\User\HomeController::class, 'store'])->name('user.contact.store');

Route::get('/login',[\App\Http\Controllers\User\HomeController::class, 'login'])->name('login');
Route::post('/login',[\App\Http\Controllers\User\HomeController::class, 'login_store'])->name('login.store');

Route::post('/register',[\App\Http\Controllers\User\HomeController::class, 'register_store'])->name('register.store');

Route::post('/student',[\App\Http\Controllers\User\HomeController::class, 'student_store'])->name('student.store');

Route::post('/newsletter',[\App\Http\Controllers\User\HomeController::class, 'newsletter_store'])->name('newsletter.store');


///////////////////////            Routes For User View                ///////////////////////////////////


///////////////////////            Routes For Admin View                ///////////////////////////////////

Route::group(['middleware' => 'isAdmin'], function () {
    
    Route::get('/dashboard',[\App\Http\Controllers\Admin\AdminController::class, 'dashboard'])->name('admin.home');

    Route::get('/BA',[\App\Http\Controllers\Admin\RecordController::class, 'ba_record'])->name('admin.ba_record');
    Route::get('/BALLB',[\App\Http\Controllers\Admin\RecordController::class, 'ballb_record'])->name('admin.ballb_record');

    Route::get('/BBA',[\App\Http\Controllers\Admin\RecordController::class, 'bba_record'])->name('admin.bba_record');

    Route::get('/BCA',[\App\Http\Controllers\Admin\RecordController::class, 'bca_record'])->name('admin.bca_record');
    Route::get('/BCOM',[\App\Http\Controllers\Admin\RecordController::class, 'bcom_record'])->name('admin.bcom_record');

    Route::get('/BE',[\App\Http\Controllers\Admin\RecordController::class, 'be_record'])->name('admin.be_record');
    Route::get('/BSC',[\App\Http\Controllers\Admin\RecordController::class, 'bsc_record'])->name('admin.bsc_record');


//////////////////////////////////collages Urls///////////////////////////////////////////
Route::get('/collage',[\App\Http\Controllers\Admin\RecordController::class, 'collage_record'])->name('admin.collage_record');

Route::get('/collage-form',[\App\Http\Controllers\Admin\RecordController::class, 'collage_record_create'])->name('admin.collage_record_create');




    /////////////////////////////////////////// Masters URL //////////////////////////////////////////


    Route::get('/MA',[\App\Http\Controllers\Admin\RecordController::class, 'ma_record'])->name('admin.ma_record');
    Route::get('/MBA',[\App\Http\Controllers\Admin\RecordController::class, 'mba_record'])->name('admin.mba_record');

    Route::get('/MCA',[\App\Http\Controllers\Admin\RecordController::class, 'mca_record'])->name('admin.mca_record');

    Route::get('/MCOM',[\App\Http\Controllers\Admin\RecordController::class, 'mcom_record'])->name('admin.mcom_record');
    Route::get('/MSC',[\App\Http\Controllers\Admin\RecordController::class, 'msc_record'])->name('admin.msc_record');

    Route::get('/ME',[\App\Http\Controllers\Admin\RecordController::class, 'mtech_record'])->name('admin.mtech_record');

    /////////////////////////////////////////// Masters URL //////////////////////////////////////////

    Route::get('/records/create',[\App\Http\Controllers\Admin\RecordController::class, 'create'])->name('admin.record.create');
    Route::post('/records/store',[\App\Http\Controllers\Admin\RecordController::class, 'store'])->name('admin.record.store');
    Route::post('/records/status/{ID}',[\App\Http\Controllers\Admin\RecordController::class, 'status_update'])->name('admin.ba_record.status');
    Route::get('/records/{ID}',[\App\Http\Controllers\Admin\RecordController::class, 'edit'])->name('admin.edit_record');
    Route::post('/records/{ID}',[\App\Http\Controllers\Admin\RecordController::class, 'update'])->name('admin.update_record');
    Route::delete('/records/{ID}',[\App\Http\Controllers\Admin\RecordController::class, 'delete'])->name('admin.delete_record');
       
    Route::get('/logout',[\App\Http\Controllers\Admin\AdminController::class, 'logout'])->name('admin.logout');
});
///////////////////////            Routes For Admin View                ///////////////////////////////////

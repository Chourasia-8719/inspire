<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg">
    <head>
        <meta charset="utf-8" />
        <title>Artbits Admin</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Art Bit Admin Dashboard" name="description" />
        <meta content="Art Bits" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('admin_assets/images/favicon.ico')); ?>">

        <!-- Layout config Js -->
        <script src="<?php echo e(asset('admin_assets/js/layout.js')); ?>"></script>
        <!-- Bootstrap Css -->
        <link href="<?php echo e(asset('admin_assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo e(asset('admin_assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo e(asset('admin_assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- custom Css-->
        <link href="<?php echo e(asset('admin_assets/css/custom.min.css')); ?>" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <!-- Begin page -->
        <div id="layout-wrapper">
            <header id="page-topbar">
                <div class="layout-width">
                    <div class="navbar-header">
                        <div class="d-flex">
                            <!-- LOGO -->
                            <div class="navbar-brand-box horizontal-logo">
                                <a href="<?php echo e(route('admin.home')); ?>" class="logo logo-dark">
                                    <span class="logo-sm">
                                       <img alt="" src="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
                                    </span>
                                    <span class="logo-lg">
                                       <img alt="" src="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
                                    </span>
                                </a>

                                <a href="<?php echo e(route('admin.home')); ?>" class="logo logo-light">
                                    <span class="logo-sm">
                                        <img alt="" src="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
                                    </span>
                                    <span class="logo-lg">
                                        <img alt="" src="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
                                    </span>
                                </a>
                            </div>
                            
                            <button type="button" class="btn btn-sm px-3 fs-16 header-item vertical-menu-btn topnav-hamburger" id="topnav-hamburger-icon">
                                <span class="hamburger-icon">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </span>
                            </button>

                            <div class="dropdown-menu dropdown-menu-lg" id="search-dropdown">
                                <div data-simplebar style="max-height: 320px;">
                                    
                                    <div class="notification-list">
                                        <!-- item -->
                                        <a href="javascript:void(0);" class="d-flex dropdown-item notify-item py-2">
                                            <img src="<?php echo e(asset('admin_assets/images/users/avatar-2.jpg')); ?>" class="me-3 rounded-circle avatar-xs"
                                                alt="user-pic">
                                            <div class="flex-1">
                                                <h6 class="m-0"><?php echo e(Auth()->user()->user); ?></h6>
                                                <span class="fs-11 mb-0 text-muted">Manager</span>
                                            </div>
                                        </a>
                                        
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="d-flex align-items-center">

                            <div class="dropdown d-md-none topbar-head-dropdown header-item">
                                <button type="button" class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle"
                                    id="page-header-search-dropdown" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="bx bx-search fs-22"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                    aria-labelledby="page-header-search-dropdown">
                                    <form class="p-3">
                                        <div class="form-group m-0">
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Search ..."
                                                    aria-label="Recipient's username">
                                                <button class="btn btn-primary" type="submit"><i
                                                        class="mdi mdi-magnify"></i></button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="dropdown ms-sm-3 header-item topbar-user">
                                <button type="button" class="btn" id="page-header-user-dropdown" data-bs-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <span class="d-flex align-items-center">
                                        <img class="rounded-circle header-profile-user" src="https://www.pngfind.com/pngs/m/93-938050_png-file-transparent-white-user-icon-png-download.png"
                                            alt="Header Avatar">
                                        <span class="text-start ms-xl-2">
                                            <span class="d-none d-xl-inline-block ms-1 fw-medium user-name-text"><?php echo e(Auth()->user()->firstname); ?> <?php echo e(Auth()->user()->lastname); ?></span>
                                            <span class="d-none d-xl-block ms-1 fs-12 text-muted user-name-sub-text">Founder</span>
                                        </span>
                                    </span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <!-- item-->
                                    <h6 class="dropdown-header">Welcome <?php echo e(Auth()->user()->firstname); ?> <?php echo e(Auth()->user()->lastname); ?></h6>
                                    <a class="dropdown-item" href="#"><i
                                            class="mdi mdi-account-circle text-muted fs-16 align-middle me-1"></i> <span
                                            class="align-middle">Profile</span></a>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>"><i
                                            class="mdi mdi-logout text-muted fs-16 align-middle me-1"></i> <span
                                            class="align-middle" data-key="t-logout">Logout</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </header>
            <!-- ========== App Menu ========== -->
            <div class="app-menu navbar-menu">
                <!-- LOGO -->
                <div class="navbar-brand-box">
                    <!-- Dark Logo-->
                    <a href="<?php echo e(route('admin.home')); ?>" class="logo logo-dark">
                        <span class="logo-sm">
                            <img src="<?php echo e(asset('admin_assets/images/logo-sm.png')); ?>" alt="" height="22">
                        </span>
                        <span class="logo-lg">
                            <img src="<?php echo e(asset('admin_assets/images/logo-dark.png')); ?>" alt="" height="17">
                        </span>
                    </a>
                    <!-- Light Logo-->
                    <a href="<?php echo e(route('admin.home')); ?>" class="logo logo-light">
                        <span class="logo-sm">
                            <img src="<?php echo e(asset('admin_assets/images/logo-sm.png')); ?>" alt="" height="22">
                        </span>
                        <span class="logo-lg">
                            <img src="<?php echo e(asset('admin_assets/images/logo-light.png')); ?>" alt="" height="17">
                        </span>
                    </a>
                    <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
                        <i class="ri-record-circle-line"></i>
                    </button>
                </div>

                <div id="scrollbar">
                    <div class="container-fluid">
            
                        <div id="two-column-menu">
                        </div>
                        <ul class="navbar-nav" id="navbar-nav">
                            <li class="menu-title"><span data-key="t-menu">Menu</span></li>
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="<?php echo e(route('admin.home')); ?>" role="button"
                                    aria-expanded="false" aria-controls="sidebarDashboards">
                                    <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards">Dashboards</span>
                                </a>
                            </li> <!-- end Dashboard Menu -->
                            
                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#ug_courses" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="ug_courses">
                                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">UG Courses Records</span>
                                </a>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.ba_record')); ?> class="nav-link" data-key="t-analytics"> View BA Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.ballb_record')); ?> class="nav-link" data-key="t-analytics"> View BA LLB Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.bba_record')); ?> class="nav-link" data-key="t-analytics"> View BBA Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.bca_record')); ?> class="nav-link" data-key="t-analytics"> View BCA Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.bcom_record')); ?> class="nav-link" data-key="t-analytics"> View B.Com Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.bcom_record')); ?> class="nav-link" data-key="t-analytics"> View B.Com Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.be_record')); ?> class="nav-link" data-key="t-analytics"> View BE/B.Tech Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="ug_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.bsc_record')); ?> class="nav-link" data-key="t-analytics"> View BSc Records </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link menu-link" href="#pg_courses" data-bs-toggle="collapse" role="button"
                                    aria-expanded="false" aria-controls="pg_courses">
                                    <i class="ri-account-circle-line"></i> <span data-key="t-authentication">PG Courses Records</span>
                                </a>
                                <div class="collapse menu-dropdown" id="pg_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.ma_record')); ?> class="nav-link" data-key="t-analytics"> View MA Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="pg_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.mba_record')); ?> class="nav-link" data-key="t-analytics"> View MBA Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="pg_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.mca_record')); ?> class="nav-link" data-key="t-analytics"> View MCA Records </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="collapse menu-dropdown" id="pg_courses">
                                    <ul class="nav nav-sm flex-column">
                                        <li class="nav-item">
                                            <a href=<?php echo e(route('admin.mcom_record')); ?> class="nav-link" data-key="t-analytics"> View M.Com Records </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->
            <!-- Vertical Overlay-->
            <div class="vertical-overlay"></div>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
                
                <!-- End Page-content -->

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> Inspire Education Admin
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Admin
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('admin_assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin_assets/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin_assets/libs/node-waves/waves.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin_assets/libs/feather-icons/feather.min.js')); ?>"></script>
        <script src="<?php echo e(asset('admin_assets/js/pages/plugins/lord-icon-2.1.0.js')); ?>"></script>
        <script src="<?php echo e(asset('admin_assets/js/plugins.js')); ?>"></script>

        <!-- Dashboard init -->
        <script  src="<?php echo e(asset('admin_assets/js/pages/dashboard-crm.init.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('admin_assets/js/app.js')); ?>"></script>
        <?php echo $__env->yieldContent('footer_link'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\inspire_new\test\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>
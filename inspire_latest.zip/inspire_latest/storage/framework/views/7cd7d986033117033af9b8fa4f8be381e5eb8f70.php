<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Create Records</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Create Records</a></li>
                                    <li class="breadcrumb-item active">Create</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->
                <div class="row mt-2">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <div class="card-header">
                                        <h4 class="card-title mb-0">Create Record</h4>
                                    </div><!-- end card header -->
                                    <div class="card-body">
                                        <form enctype="multipart/form-data" action="<?php echo e(route('admin.record.store')); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label class="control-label" for="input-name">Course Type</label>
                                                        <select name="standerd" placeholder="Course Type" id="input-name"
                                                            class="form-control">
                                                            <option value="">Select Type</option>
                                                            <option value="UG">Under Graduate</option>
                                                            <option value="PG">Post Graduate</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label class="control-label" for="input-name">Course Name</label>
                                                        <select name="course_name" placeholder="Course Name" id="input-name"
                                                            class="form-control">
                                                            <option value="">Select Name</option>
                                                            <option value="BA">BA</option>
                                                            <option value="BCOM">B.com</option>

                                                            <option value="BSC">BSc</option>
                                                            <option value="BTECH">B. TECH</option>

                                                            <option value="BALLB">BA LLB</option>
                                                            <option value="BBA">BBA</option>

                                                            <option value="BCA">BCA</option>
                                                            <option value="BE">BE</option>

                                                            <option value="MA">MA</option>
                                                            <option value="MCOM">M.com</option>

                                                            <option value="MSC">MSc</option>
                                                            <option value="MTECH">M. TECH</option>

                                                            <option value="MBA">MBA</option>
                                                            <option value="MCA">MCA</option>

                                                            <option value="LLBHONOURS">LLB Honors</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group mb-3">
                                                        <label class="control-label" for="input-name">Course Stream</label>
                                                        <select name="stream" placeholder="Course Type" id="input-name"
                                                            class="form-control">
                                                            <option value="">Select Type</option>
                                                            <option value="Mechanical Engineering">Mechanical Engineering</option>
                                                            <option value="Civil Engineering">Civil Engineering</option>
                                                            <option value="Computer Engineering">Computer Engineering</option>
                                                            <option value="Electronic Engineering">Electronic Engineering</option>
                                                        </select>
                                                    </div>
                                                </div>


                                                <div class="col-lg-12">
                                                    <div class="text-end">
                                                        <button type="submit" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </div>
                                                <!--end col-->
                                            </div>
                                            <!--end row-->
                                        </form>
                                    </div>
                                    <!-- end card body -->
                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div>
                    <!-- end col -->
                </div>
            </div> <!-- container-fluid -->
        </div>
    <?php $__env->stopSection(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\inspire\resources\views/admin/pages/Collage/collage_form.blade.php ENDPATH**/ ?>
<header class="header-area">
    <div class="header-top bg-img" style="background-image:url('assets/img/icon-img/header-shape.png');">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-7 col-12 col-sm-8">
                    <div class="header-contact">
                        <ul>
                            <li><i class="fa fa-phone"></i> +91 930000941</li>
                            <li><i class="fa fa-envelope-o"></i><a href="#">info@theinspireeducationsociety.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-5 col-12 col-sm-4">
                    <div class="login-register">
                        <ul>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-bottom sticky-bar clearfix">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-6 col-4">
                    <div class="logo">
                        <a href="<?php echo e(route('user.home')); ?>">
                            <img alt="" src="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
                        </a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-6 col-8">
                    <div class="menu-cart-wrap">
                        <div class="main-menu">
                            <nav>
                                <ul>
                                    <li><a href="<?php echo e(route('user.home')); ?>"> HOME </a></li>
                                    <li><a href="<?php echo e(route('user.about')); ?>"> ABOUT  </a></li>
                                    <li><a href="<?php echo e(route('user.course')); ?>"> COURSES / PROGRAMMES  </a></li>
                                    <li><a href="<?php echo e(route('user.contact')); ?>"> CONTACT US </a></li>
                                </ul>
                            </nav>
                        </div>
                       
                    </div>
                </div>
            </div>
            <!-- mobile hamberger -->
            <div class="mobile-menu-area">
                <div class="mobile-menu">
                    <nav id="mobile-menu-active">
                        <ul class="menu-overflow">
                            <li><a href="<?php echo e(route('user.home')); ?>"> HOME </a></li>
                            <li><a href="<?php echo e(route('user.about')); ?>"> ABOUT  </a></li>
                            <li><a href="<?php echo e(route('user.course')); ?>"> COURSES </a></li>
                            <li><a href="<?php echo e(route('user.contact')); ?>"> CONTACT US </a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\inspire_latest\resources\views/partials/header.blade.php ENDPATH**/ ?>
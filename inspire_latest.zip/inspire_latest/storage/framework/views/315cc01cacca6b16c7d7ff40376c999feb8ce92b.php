<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0">Update Records</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Update Records</a></li>
                                <li class="breadcrumb-item active">Update</li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row mt-2">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="card-header">
                                    <h4 class="card-title mb-0">Update Record</h4>
                                </div><!-- end card header -->
                                <div class="card-body">
                                    <form enctype="multipart/form-data" action="<?php echo e(route('admin.update_record',$data->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-name">Course Type</label>
                                                        <h5 style="color:red">Selected Type: <?php echo e($data['course_type']); ?></h5>         
                                                    <select name="course_type" value="<?php echo e($data['course_type']); ?>" placeholder="Course Type" id="input-name" class="form-control">
                                                        <option value="">Select Type</option>
                                                        <option value="UG">Under Graduate</option>
                                                        <option value="PG">Post Graduate</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-name">Course Name</label>
                                                    <h5 style="color:red">Selected Name: <?php echo e($data['course_name']); ?></h5>
                                                    <select name="course_name" value="<?php echo e($data['course_name']); ?>" placeholder="Course Name" id="input-name" class="form-control">
                                                        <option value="">Select Name</option>
                                                        <option value="BA">BA</option>
                                                        <option value="BCOM">B.com</option>

                                                        <option value="BSC">BSc</option>
                                                        <option value="BTECH">B. TECH</option>

                                                        <option value="BALLB">BA LLB</option>
                                                        <option value="BBA">BBA</option>

                                                        <option value="BCA">BCA</option>
                                                        <option value="BE">BE</option>

                                                        <option value="MA">MA</option>
                                                        <option value="MCOM">M.com</option>

                                                        <option value="MSC">MSc</option>
                                                        <option value="MTECH">M. TECH</option>

                                                        <option value="MBA">MBA</option>
                                                        <option value="MCA">MCA</option>

                                                        <option value="LLBHONOURS">LLB Honors</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Tenth Marks</label>
                                                    <input type="text" name="tenth" value="<?php echo e($data['tenth']); ?>" placeholder="Tenth Marks" id="input-slug" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Tenth/'.$data['tenth_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Tenth Marks Sheet Photo</label> <br>
                                                <input type="file" 
                                                        name="tenth_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-short_description">Twelth marks</label>
                                                    <input type="text" name="twelth" value="<?php echo e($data['twelth']); ?>" placeholder="Twelth marks" id="input-short_description" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Twelth/'.$data['twelth_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Twelth Marks Sheet Photo</label> <br>
                                                <input type="file" 
                                                        name="twelth_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Income </label>
                                                    <input type="text" name="income" value="<?php echo e($data['income']); ?>" placeholder="Income" id="input-slug" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Income/'.$data['income_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Income Photo</label> <br>
                                                <input type="file" 
                                                        name="income_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Caste </label>
                                                    <input type="text" name="caste" value="<?php echo e($data['caste']); ?>" placeholder="Caste" id="input-slug" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Caste/'.$data['caste_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Caste Photo</label> <br>
                                                <input type="file" 
                                                        name="caste_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Domicile </label>
                                                    <input type="text" name="domicile" value="<?php echo e($data['domicile']); ?>" placeholder="Domicile" id="input-slug" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Domicile/'.$data['domicile_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Domicile Photo</label> <br>
                                                <input type="file" 
                                                        name="domicile_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Aadhar Number </label>
                                                    <input type="text" name="adhar" value="<?php echo e($data['adhar']); ?>" placeholder="Aadhar Number" id="input-slug" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Aadhar/'.$data['adhar_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Aadhar Photo</label> <br>
                                                <input type="file" 
                                                        name="adhar_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">SSSM ID </label>
                                                    <input type="text" name="sssm" value="<?php echo e($data['sssm']); ?>" placeholder="SSSM ID" id="input-slug" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-description">Email</label>
                                                    <input type="email" name="email" value="<?php echo e($data['email']); ?>" placeholder="Email" id="input-description" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Contact Number </label>
                                                    <input type="text" name="contact_no"  value="<?php echo e($data['contact_no']); ?>" placeholder="Contact Number" id="input-slug" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/PassportSizePhoto/'.$data['passport_size_photo'])); ?>" alt="" style="width:50px;height:50px">

                                                <label class="control-label" for="input-slug">Passport Size Photo</label> <br>
                                                <input type="file" 
                                                        name="passport_size_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Hitgrahi</label>
                                                    <input type="text" name="hitgrahi" value="<?php echo e($data['hitgrahi']); ?>" placeholder="Hitgrahi" id="input-slug" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Hitgrahi/'.$data['hitgrahi_photo'])); ?>" alt="" style="width:50px;height:50px">

                                                <label class="control-label" for="input-slug">Hitgrahi Photo</label> <br>
                                                <input type="file" 
                                                        name="hitgrahi_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-name">Scholar Base</label>
                                                    <h5 style="color:red">Selected Name: <?php if($data['scholar_type'] == '0'): ?> No Scholar base <?php else: ?> Scholar base <?php endif; ?> </h5>
                                                    <select name="scholar_type" value="$data['scholar_type']" placeholder="Scholar Base" id="input-name" class="form-control">
                                                        <option value="">Select Scholar Level</option>
                                                        <option value="0">No Scholar</option>
                                                        <option value="1">Scholar Base</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <div class="form-group mb-3">
                                                    <label class="control-label" for="input-slug">Graduation</label>
                                                    <input type="text" name="graduation" value="<?php echo e($data['graduation']); ?>" placeholder="Graduation Marks" id="input-slug" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <img src="<?php echo e(URL::asset('/Graduation/'.$data['graduation_photo'])); ?>" alt="" style="width:50px;height:50px">
                                                <label class="control-label" for="input-slug">Graduation Photo</label> <br>
                                                <input type="file" 
                                                        name="graduation_photo"
                                                        accept=".jpg, .jpeg, .png">
                                                        <br>
                                                        <br>
                                            </div>

                                            <div class="col-lg-12">
                                                <div class="text-end">
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </div><!--end col-->
                                        </div><!--end row-->
                                    </form>
                                </div>
                                <!-- end card body -->
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>
                <!-- end col -->
            </div>
        </div> <!-- container-fluid -->
    </div>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\inspire\resources\views/admin/pages/update_record.blade.php ENDPATH**/ ?>
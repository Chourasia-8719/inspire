<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('content'); ?>
        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Collage List</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                    <li class="breadcrumb-item active">Collage List</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">Collage List</h4>
                                <a href="<?php echo e(route('admin.collage_record_create')); ?>"><button class="btn btn-warning ">Create Collage</button></a>
                            </div><!-- end card header -->

                            <div class="card-body">
                                
                                <div class="live-preview">
                                    <div class="table-responsive table-card">
                                        <table class="table align-middle table-nowrap mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Collage Name</th>
                                                    <th scope="col">Standerd</th>
                                                    <th scope="col">University</th>
                                                    <th scope="col">Location</th>
                                                    <th scope="col">Courses </th>
                                                    <th scope="col" style="width: 150px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                <td><?php echo e($p['id']); ?></td>
                                                <td><?php echo e($p['course_name']); ?></td>
                                                <td><?php echo e($p['course_type']); ?></td>
                                                <td><?php echo e($p['tenth']); ?></td>
                                                <td><?php echo e($p['twelth']); ?></td>

                                                <td><?php echo e($p['income']); ?></td>
                                                <td><?php echo e($p['caste']); ?></td>
                                                <td><?php echo e($p['domicile']); ?></td>
                                                <td><?php echo e($p['adhar']); ?></td>
                                                
                                                
                                                <td><?php echo e($p['sssm']); ?></td>
                                                <td><?php echo e($p['email']); ?></td>
                                                <td><?php echo e($p['contact_no']); ?></td>
                                                <td><?php echo e($p['photo']); ?></td>
                                                <td><?php echo e($p['hitgrahi']); ?></td>
                                                    
                                                <td>
                                                    <?php if($p['activated'] == '1'): ?>    
                                                        <form action="<?php echo e(route('admin.ba_record.status', $p->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('post'); ?>
                                                            <input type="hidden" value="0" name="activated">
                                                            <button class="btn btn-success" type="submit"><a>Deactivate</a></button>
                                                        </form>     
                                                    <?php else: ?>
                                                    <form action="<?php echo e(route('admin.ba_record.status', $p->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('post'); ?>
                                                        <input type="hidden" value="1" name="activated">
                                                        <button class="btn btn-danger" type="submit"><a>Activate</a></button>
                                                    </form> 
                                                    <?php endif; ?>
                                                </td> 
                                                <td><?php echo e($p['scholar_type']); ?></td>
                                                <td><?php echo e($p['graduation']); ?></td>
                                                
                                                <td>
                                                    <button class="btn btn-warning"><a href="<?php echo e(route('admin.edit_record', $p->id)); ?>">Edit</a></button>
                                                    <form action="<?php echo e(route('admin.delete_record', $p->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button class="btn btn-danger" type="submit"><a>Delete</a></button>
                                                    </form>
                                                </td>     
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div><!-- end card-body -->
                        </div><!-- end card -->
                    </div><!-- end col -->
                </div><!-- end row -->

            </div>
            <!-- container-fluid -->
        </div>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\inspire_latest\resources\views/admin/pages/Collage/collage_list.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('content'); ?>
        <div class="breadcrumb-area">
            <div class="breadcrumb-top default-overlay bg-img breadcrumb-overly-5 pt-100 pb-95" style="background-image:url('assets/img/bg/breadcrumb-bg-6.jpg');">
                <div class="container">
                    <h2>Contact Us</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore .</p>
                </div>
            </div>
            <div class="breadcrumb-bottom">
                <div class="container">
                    <ul>
                        <li><a href="#">Home</a> <span><i class="fa fa-angle-double-right"></i>Contact Us</span></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="contact-area pt-130 pb-130">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7">
                        <div class="contact-map mr-70">
                            <div id="map"></div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="contact-form">
                            <div class="contact-title mb-45">
                                <h2>Stay <span>Connected</span></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipis do eiusmod tempor indunt ut labore et dolore magna aliqua.</p>
                            </div>
                            <form action="<?php echo e(route('user.contact.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input name="name" placeholder="Name*" type="text">
                                <?php if($errors->has('name')): ?>
                                    <div class="error bg-warning text-white"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                                <input name="email" placeholder="Email*" type="email">
                                <?php if($errors->has('email')): ?>
                                    <div class="error bg-warning text-white"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                                <input name="subject" placeholder="Subject*" type="text">
                                <?php if($errors->has('subject')): ?>
                                    <div class="error bg-warning text-white"><?php echo e($errors->first('subject')); ?></div>
                                <?php endif; ?>
                                <textarea name="message" placeholder="Message"></textarea>
                                <?php if($errors->has('message')): ?>
                                    <div class="error bg-warning text-white"><?php echo e($errors->first('message')); ?></div>
                                <?php endif; ?>
                                <button class="submit btn-style" type="submit">SEND MESSAGE</button>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="contact-info-area bg-img pt-180 pb-140 default-overlay" style="background-image:url(assets/img/bg/contact-info.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="single-contact-info mb-30 text-center">
                            <div class="contact-info-icon">
                                <span><i class="fa fa-calendar-o"></i></span>
                            </div>
                            <p>Uttara, Dhaka, Bangladesh <br>Opposite site Of Yellow.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="single-contact-info mb-30 text-center">
                            <div class="contact-info-icon">
                                <span><i class="fa fa-calendar-o"></i></span>
                            </div>
                            <div class="contact-info-phn">
                                <div class="info-phn-title">
                                    <span>Phone : </span>
                                </div>
                                <div class="info-phn-number">
                                    <p>+091111111111</p>
                                    <p>+091111111111</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-12">
                        <div class="single-contact-info mb-30 text-center">
                            <div class="contact-info-icon">
                                <span><i class="fa fa-calendar-o"></i></span>
                            </div>
                            <a href="#">education@email.com</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="brand-logo-area pt-130 pb-130">
            <div class="container">
                <div class="brand-logo-active owl-carousel">
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/1.png" alt=""></a>
                    </div>
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
                    </div>
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/3.png" alt=""></a>
                    </div>
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/4.png" alt=""></a>
                    </div>
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/5.png" alt=""></a>
                    </div>
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/6.png" alt=""></a>
                    </div>
                    <div class="single-brand-logo">
                        <a href="#"><img src="assets/img/brand-logo/2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\inspire_latest\resources\views/user/contact.blade.php ENDPATH**/ ?>
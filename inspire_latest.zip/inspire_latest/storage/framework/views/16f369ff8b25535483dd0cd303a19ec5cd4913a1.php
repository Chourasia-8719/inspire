<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>The Inspire Education</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
    
    <!-- CSS
	============================================ -->
   
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.min.css')); ?>">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- Modernizer JS -->
    <style>
        #loader {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            background: rgba(0,0,0,0.75) url("<?php echo e(URL::asset('main_site_imgs/loader.gif')); ?>") no-repeat center center;
            z-index: 99999;
        }
    </style>
    <script src="<?php echo e(asset('assets/js/vendor/modernizr-3.11.7.min.js')); ?>"></script>
    <?php echo $__env->yieldContent("header_css"); ?>
</head>
<body>
    <div id='loader'></div>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- JS
    ============================================ -->

    <!-- jQuery JS -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery-v2.2.4.min.js')); ?>"></script>
    <!-- Popper JS -->
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <!-- Plugins JS -->
    <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
    <!-- Ajax Mail -->
    <script src="<?php echo e(asset('assets/js/ajax-mail.js')); ?>"></script>
    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('#loader').show();
            setTimeout(function () {
                $('#loader').hide();
            }, 2000);
        });
    </script>
    <?php echo $__env->yieldContent('footer_link'); ?>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\inspire_latest\resources\views/components/app-layout.blade.php ENDPATH**/ ?>
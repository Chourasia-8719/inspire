<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Login Page</title>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" ></script>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('main_site_imgs/logo.png')); ?>">
    <style>
    body {font-family: Arial, Helvetica, sans-serif;text-align:center}
    form {border: 3px solid #f1f1f1;}

    p{
        color:#f44336;
        font-size: 1rem;
        text-transform:uppercase;
    }   
    input[type=text], input[type=password], input[type=email]{
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    }

    button {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 20%;
    }

    button:hover {
    opacity: 0.8;
    }

    .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    }

    img.avatar {
    width: 10%;
    border-radius: 50%;
    }

    .container {
    padding: 16px;
    }

    span.psw {
    float: right;
    padding-top: 16px;
    }

    /* Change styles for span and cancel button on extra small screens */
    @media  screen and (max-width: 300px) {
    span.psw {
        display: block;
        float: none;
    }

    input[type=text], input[type=password], input[type=email]{
         width: 100%;
    }

    button {
        width: 100%;
    }

    }
    </style>
</head>
<body>
    <div class="container">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li><br><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        <form action="<?php echo e(route('login.store')); ?>" method="post">
             <?php echo csrf_field(); ?>
        <div class="imgcontainer">
            <img src="<?php echo e(asset('main_site_imgs/user.jpg')); ?>" alt="Avatar" class="avatar">
            <p>Login Form</p>
        </div>

        <div class="container">
            <input type="email" placeholder="Enter Email" name="email" required>

            <input type="password" placeholder="Enter Password" name="password" required><br>
                
            <button type="submit">Login</button>
            <a href="<?php echo e(route('user.home')); ?>"><button type="button" class="bg-dark text-white">Back</button></a>
        </div>
        </form>
    
       

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\inspire_new\test\resources\views/auth/login.blade.php ENDPATH**/ ?>
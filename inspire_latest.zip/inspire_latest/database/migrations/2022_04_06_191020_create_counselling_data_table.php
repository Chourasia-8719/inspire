<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCounsellingDataTable extends Migration
{
    
    public function up()
    {
        Schema::create('counselling_data', function (Blueprint $table) {
            $table->id();
            $table->enum('course_type',['UG','PG'])->comment('UG for UnderGraduate and PG for PostGraduation')->nullable();
            $table->enum('course_name',['BA','BCOM','BSC','BALLB','BBA','BCA','BE/BTECH','MA','MCOM','MSC','MTECH','MBA','MCA','LLBHONOURS'])->nullable();
            
            $table->float('tenth')->nullable();
            $table->string('tenth_photo')->nullable();

            $table->string('twelth')->nullable();
            $table->string('twelth_photo')->nullable();

            $table->string('income')->nullable();
            $table->string('income_photo')->nullable();

            $table->string('caste')->nullable();
            $table->string('caste_photo')->nullable();

            $table->string('domicile')->nullable();
            $table->string('domicile_photo')->nullable();

            $table->string('adhar')->nullable();
            $table->string('adhar_photo')->nullable();

            $table->string('sssm')->nullable();
            $table->string('email')->nullable();

            $table->string('contact_no')->nullable();
            $table->string('passport_size_photo')->nullable();

            $table->string('hitgrahi')->nullable();
            $table->string('hitgrahi_photo')->nullable();

            $table->boolean('activated')->nullable();

            $table->enum('scholar_type',['0','1'])->comment('0 for No Scholar Student and 1 for Scholar Student')->nullable();
           
            $table->string('graduation')->nullable();
            $table->string('graduation_photo')->nullable();

            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down()
    {
        Schema::dropIfExists('counselling_data');
    }
}

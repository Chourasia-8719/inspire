<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>The Inspire Education</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{asset('assets/img/logo/logo.png')}}">
    
    <!-- CSS
	============================================ -->
   
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="{{asset('assets/css/icons.min.css')}}">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="{{asset('assets/css/plugins.css')}}">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <!-- Modernizer JS -->
    <style>
        #loader {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            background: rgba(0,0,0,0.75) url("{{URL::asset('main_site_imgs/loader.gif')}}") no-repeat center center;
            z-index: 99999;
        }
    </style>
    <script src="{{asset('assets/js/vendor/modernizr-3.11.7.min.js')}}"></script>
    @yield("header_css")
</head>
<body>
    <div id='loader'></div>
    @include('partials.header')
    @if (session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
    @endif
    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif
    @yield('content')
    @include('partials.footer')
    <!-- JS
    ============================================ -->

    <!-- jQuery JS -->
    <script src="{{asset('assets/js/vendor/jquery-v2.2.4.min.js')}}"></script>
    <!-- Popper JS -->
    <script src="{{asset('assets/js/popper.min.js')}}"></script>
    <!-- Bootstrap JS -->
    <script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
    <!-- Plugins JS -->
    <script src="{{asset('assets/js/plugins.js')}}"></script>
    <!-- Ajax Mail -->
    <script src="{{asset('assets/js/ajax-mail.js')}}"></script>
    <!-- Main JS -->
    <script src="{{asset('assets/js/main.js')}}"></script>
    <script>
        $(document).ready(function(){
            $('#loader').show();
            setTimeout(function () {
                $('#loader').hide();
            }, 2000);
        });
    </script>
    @yield('footer_link')
</body>
</html>


<x-admin-layout>
    @section('content')
        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Collage List</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                    <li class="breadcrumb-item active">Collage List</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">Collage List</h4>
                                <a href="{{route('admin.collage_record_create')}}"><button class="btn btn-warning ">Create Collage</button></a>
                            </div><!-- end card header -->

                            <div class="card-body">
                                
                                <div class="live-preview">
                                    <div class="table-responsive table-card">
                                        <table class="table align-middle table-nowrap mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Collage Name</th>
                                                    <th scope="col">Standerd</th>
                                                    <th scope="col">University</th>
                                                    <th scope="col">Location</th>
                                                    <th scope="col">Courses </th>
                                                    <th scope="col" style="width: 150px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($data as $p)
                                                <tr>
                                                <td>{{$p['id']}}</td>
                                                <td>{{$p['course_name']}}</td>
                                                <td>{{$p['course_type']}}</td>
                                                <td>{{$p['tenth']}}</td>
                                                <td>{{$p['twelth']}}</td>

                                                <td>{{$p['income']}}</td>
                                                <td>{{$p['caste']}}</td>
                                                <td>{{$p['domicile']}}</td>
                                                <td>{{$p['adhar']}}</td>
                                                
                                                
                                                <td>{{$p['sssm']}}</td>
                                                <td>{{$p['email']}}</td>
                                                <td>{{$p['contact_no']}}</td>
                                                <td>{{$p['photo']}}</td>
                                                <td>{{$p['hitgrahi']}}</td>
                                                    
                                                <td>
                                                    @if($p['activated'] == '1')    
                                                        <form action="{{ route('admin.ba_record.status', $p->id) }}" method="POST">
                                                            @csrf
                                                            @method('post')
                                                            <input type="hidden" value="0" name="activated">
                                                            <button class="btn btn-success" type="submit"><a>Deactivate</a></button>
                                                        </form>     
                                                    @else
                                                    <form action="{{ route('admin.ba_record.status', $p->id) }}" method="POST">
                                                        @csrf
                                                        @method('post')
                                                        <input type="hidden" value="1" name="activated">
                                                        <button class="btn btn-danger" type="submit"><a>Activate</a></button>
                                                    </form> 
                                                    @endif
                                                </td> 
                                                <td>{{$p['scholar_type']}}</td>
                                                <td>{{$p['graduation']}}</td>
                                                
                                                <td>
                                                    <button class="btn btn-warning"><a href="{{route('admin.edit_record', $p->id)}}">Edit</a></button>
                                                    <form action="{{ route('admin.delete_record', $p->id) }}" method="POST">
                                                        @csrf
                                                        @method('delete')
                                                        <button class="btn btn-danger" type="submit"><a>Delete</a></button>
                                                    </form>
                                                </td>     
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div><!-- end card-body -->
                        </div><!-- end card -->
                    </div><!-- end col -->
                </div><!-- end row -->

            </div>
            <!-- container-fluid -->
        </div>
    @endsection
</x-admin-layout>
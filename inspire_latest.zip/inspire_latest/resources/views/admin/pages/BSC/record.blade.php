<x-admin-layout>
    @section('content')
        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">B.Sc</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                    <li class="breadcrumb-item active">B.Sc</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->

                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1">B.Sc Info</h4>
                                <a href="{{route('admin.record.create')}}"><button class="btn btn-warning ">Create B.Sc Record</button></a>
                            </div><!-- end card header -->

                            <div class="card-body">
                                
                                <div class="live-preview">
                                    <div class="table-responsive table-card">
                                        <table class="table align-middle table-nowrap mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Course Name</th>
                                                    <th scope="col">Course Type</th>
                                                    <th scope="col">10 Th</th>
                                                    <th scope="col">12 Th</th>
                                                    <th scope="col">Income </th>
                                                    <th scope="col">Caste</th>

                                                    <th scope="col">Domicile</th>
                                                    <th scope="col">Aadhar</th>
                                                    <th scope="col">SSSM ID</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Contact No. </th>
                                                    <th scope="col">Passport Photo</th>
                                                    
                                                    <th scope="col">HitGrahi</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Scholar Type</th>
                                                    <th scope="col">Gradute Student</th>
                                                    
                                                    <th scope="col" style="width: 150px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($data as $p)
                                                <tr>
                                                <td>{{$p['id']}}</td>
                                                <td>{{$p['course_name']}}</td>
                                                <td>{{$p['course_type']}}</td>
                                                <td>{{$p['tenth']}}</td>
                                                <td>{{$p['twelth']}}</td>

                                                <td>{{$p['income']}}</td>
                                                <td>{{$p['caste']}}</td>
                                                <td>{{$p['domicile']}}</td>
                                                <td>{{$p['adhar']}}</td>
                                                
                                                
                                                <td>{{$p['sssm']}}</td>
                                                <td>{{$p['email']}}</td>
                                                <td>{{$p['contact_no']}}</td>
                                                <td>{{$p['photo']}}</td>
                                                <td>{{$p['hitgrahi']}}</td>
                                                    
                                                <td>
                                                    @if($p['activated'] == '1')    
                                                        <form action="{{ route('admin.ba_record.status', $p->id) }}" method="POST">
                                                            @csrf
                                                            @method('post')
                                                            <input type="hidden" value="0" name="activated">
                                                            <button class="btn btn-success" type="submit"><a>Deactivate</a></button>
                                                        </form>     
                                                    @else
                                                    <form action="{{ route('admin.ba_record.status', $p->id) }}" method="POST">
                                                        @csrf
                                                        @method('post')
                                                        <input type="hidden" value="1" name="activated">
                                                        <button class="btn btn-danger" type="submit"><a>Activate</a></button>
                                                    </form> 
                                                    @endif
                                                </td> 
                                                <td>{{$p['scholar_type']}}</td>
                                                <td>{{$p['graduation']}}</td>
                                                
                                                <td>
                                                    <button class="btn btn-warning"><a href="{{route('admin.edit_record', $p->id)}}">Edit</a></button>
                                                    <form action="{{ route('admin.delete_record', $p->id) }}" method="POST">
                                                        @csrf
                                                        @method('delete')
                                                        <button class="btn btn-danger" type="submit"><a>Delete</a></button>
                                                    </form>
                                                </td>     
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="d-none code-view">
                                    <pre class="language-markup" style="height: 275px;"><code>&lt;div class=&quot;table-responsive table-card&quot;&gt;
                                        &lt;table class=&quot;table table-nowrap mb-0&quot;&gt;
                                            &lt;thead class=&quot;table-light&quot;&gt;
                                                &lt;tr&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;
                                                        &lt;div class=&quot;form-check&quot;&gt;
                                                            &lt;input class=&quot;form-check-input&quot; type=&quot;checkbox&quot; value=&quot;&quot; id=&quot;cardtableCheck&quot;&gt;
                                                            &lt;label class=&quot;form-check-label&quot; for=&quot;cardtableCheck&quot;&gt;&lt;/label&gt;
                                                        &lt;/div&gt;
                                                    &lt;/th&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;Id&lt;/th&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;Name&lt;/th&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;Date&lt;/th&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;Total&lt;/th&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;Status&lt;/th&gt;
                                                    &lt;th scope=&quot;col&quot;&gt;Action&lt;/th&gt;
                                                &lt;/tr&gt;
                                            &lt;/thead&gt;
                                            &lt;tbody&gt;
                                                &lt;tr&gt;
                                                    &lt;td&gt;
                                                        &lt;div class=&quot;form-check&quot;&gt;
                                                            &lt;input class=&quot;form-check-input&quot; type=&quot;checkbox&quot; value=&quot;&quot; id=&quot;cardtableCheck01&quot;&gt;
                                                            &lt;label class=&quot;form-check-label&quot; for=&quot;cardtableCheck01&quot;&gt;&lt;/label&gt;
                                                        &lt;/div&gt;
                                                    &lt;/td&gt;
                                                    &lt;td&gt;&lt;a href=&quot;#&quot; class=&quot;fw-semibold&quot;&gt;#VL2110&lt;/a&gt;&lt;/td&gt;
                                                    &lt;td&gt;William Elmore&lt;/td&gt;
                                                    &lt;td&gt;07 Oct, 2021&lt;/td&gt;
                                                    &lt;td&gt;$24.05&lt;/td&gt;
                                                    &lt;td&gt;&lt;span class=&quot;badge bg-success&quot;&gt;Paid&lt;/span&gt;&lt;/td&gt;
                                                    &lt;td&gt;
                                                        &lt;button type=&quot;button&quot; class=&quot;btn btn-sm btn-light&quot;&gt;Details&lt;/button&gt;
                                                    &lt;/td&gt;
                                                &lt;/tr&gt;
                                                &lt;tr&gt;
                                                    &lt;td&gt;
                                                        &lt;div class=&quot;form-check&quot;&gt;
                                                            &lt;input class=&quot;form-check-input&quot; type=&quot;checkbox&quot; value=&quot;&quot; id=&quot;cardtableCheck02&quot;&gt;
                                                            &lt;label class=&quot;form-check-label&quot; for=&quot;cardtableCheck02&quot;&gt;&lt;/label&gt;
                                                        &lt;/div&gt;
                                                    &lt;/td&gt;
                                                    &lt;td&gt;&lt;a href=&quot;#&quot; class=&quot;fw-semibold&quot;&gt;#VL2109&lt;/a&gt;&lt;/td&gt;
                                                    &lt;td&gt;Georgie Winters&lt;/td&gt;
                                                    &lt;td&gt;07 Oct, 2021&lt;/td&gt;
                                                    &lt;td&gt;$26.15&lt;/td&gt;
                                                    &lt;td&gt;&lt;span class=&quot;badge bg-success&quot;&gt;Paid&lt;/span&gt;&lt;/td&gt;
                                                    &lt;td&gt;
                                                        &lt;button type=&quot;button&quot; class=&quot;btn btn-sm btn-light&quot;&gt;Details&lt;/button&gt;
                                                    &lt;/td&gt;
                                                &lt;/tr&gt;
                                                &lt;tr&gt;
                                                    &lt;td&gt;
                                                        &lt;div class=&quot;form-check&quot;&gt;
                                                            &lt;input class=&quot;form-check-input&quot; type=&quot;checkbox&quot; value=&quot;&quot; id=&quot;cardtableCheck03&quot;&gt;
                                                            &lt;label class=&quot;form-check-label&quot; for=&quot;cardtableCheck03&quot;&gt;&lt;/label&gt;
                                                        &lt;/div&gt;
                                                    &lt;/td&gt;
                                                    &lt;td&gt;&lt;a href=&quot;#&quot; class=&quot;fw-semibold&quot;&gt;#VL2108&lt;/a&gt;&lt;/td&gt;
                                                    &lt;td&gt;Whitney Meier&lt;/td&gt;
                                                    &lt;td&gt;06 Oct, 2021&lt;/td&gt;
                                                    &lt;td&gt;$21.25&lt;/td&gt;
                                                    &lt;td&gt;&lt;span class=&quot;badge bg-danger&quot;&gt;Refund&lt;/span&gt;&lt;/td&gt;
                                                    &lt;td&gt;
                                                        &lt;button type=&quot;button&quot; class=&quot;btn btn-sm btn-light&quot;&gt;Details&lt;/button&gt;
                                                    &lt;/td&gt;
                                                &lt;/tr&gt;
                                                &lt;tr&gt;
                                                    &lt;td&gt;
                                                        &lt;div class=&quot;form-check&quot;&gt;
                                                            &lt;input class=&quot;form-check-input&quot; type=&quot;checkbox&quot; value=&quot;&quot; id=&quot;cardtableCheck04&quot;&gt;
                                                            &lt;label class=&quot;form-check-label&quot; for=&quot;cardtableCheck04&quot;&gt;&lt;/label&gt;
                                                        &lt;/div&gt;
                                                    &lt;/td&gt;
                                                    &lt;td&gt;&lt;a href=&quot;#&quot; class=&quot;fw-semibold&quot;&gt;#VL2107&lt;/a&gt;&lt;/td&gt;
                                                    &lt;td&gt;Justin Maier&lt;/td&gt;
                                                    &lt;td&gt;05 Oct, 2021&lt;/td&gt;
                                                    &lt;td&gt;$25.03&lt;/td&gt;
                                                    &lt;td&gt;&lt;span class=&quot;badge bg-success&quot;&gt;Paid&lt;/span&gt;&lt;/td&gt;
                                                    &lt;td&gt;
                                                        &lt;button type=&quot;button&quot; class=&quot;btn btn-sm btn-light&quot;&gt;Details&lt;/button&gt;
                                                    &lt;/td&gt;
                                                &lt;/tr&gt;
                                            &lt;/tbody&gt;
                                        &lt;/table&gt;
                                    &lt;/div&gt;</code></pre>
                                </div>
                            </div><!-- end card-body -->
                        </div><!-- end card -->
                    </div><!-- end col -->
                </div><!-- end row -->

            </div>
            <!-- container-fluid -->
        </div>
    @endsection
</x-admin-layout>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CounsellingData extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'counselling_data';

    protected $fillable = [
        'course_type',
        'course_name',
        
        'tenth',
        'tenth_photo',

        'twelth',
        'twelth_photo',

        'income',
        'income_photo',

        'caste',
        'caste_photo',

        'domicile',
        'domicile_photo',

        'adhar',
        'adhar_photo',

        'sssm',
        'email',
        'contact_no',
        'passport_size_photo',
        'hitgrahi',
        'hitgrahi_photo',

        'activated',
        'scholar_type',
        'graduation',
        'graduation_photo'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Collage extends Model
{

    protected $table = 'college_list';

    use HasFactory, SoftDeletes;
    
    protected $fillable = [
        'name',
        'course_id',
        'university',
        'location',
        'deleted_at',
        'created_at',
        'updated_at'
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];
}

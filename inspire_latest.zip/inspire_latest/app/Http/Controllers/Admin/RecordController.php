<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{CounsellingData,Collage};
use Illuminate\Support\Facades\Validator;

class RecordController extends Controller
{
    public function ba_record(Request $request){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BA'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BA.record',['data'=>$data]);
    }

    public function ballb_record(Request $request){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BALLB'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BALLB.record',['data'=>$data]);
    }

    public function bba_record(){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BBA'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BBA.record',['data'=>$data]);
    }

    public function bca_record(){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BCA'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BCA.record',['data'=>$data]);
    }


    public function bcom_record(){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BCOM'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BCOM.record',['data'=>$data]);
    }

    public function be_record(){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BE/BTECH'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BE.record',['data'=>$data]);
    }
    
    public function bsc_record(){
        $data = CounsellingData::where(['course_type'=>'UG','course_name'=>'BSC'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.BSC.record',['data'=>$data]);
    }

    public function ma_record(){
        $data = CounsellingData::where(['course_type'=>'PG','course_name'=>'MA'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.MA.record',['data'=>$data]);
    }

    public function mba_record(){
        $data = CounsellingData::where(['course_type'=>'PG','course_name'=>'MBA'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.MBA.record',['data'=>$data]);
    }

    public function mca_record(){
        $data = CounsellingData::where(['course_type'=>'PG','course_name'=>'MCA'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.MCA.record',['data'=>$data]);
    }

    public function mcom_record(){
        $data = CounsellingData::where(['course_type'=>'PG','course_name'=>'MCOM'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.MCOM.record',['data'=>$data]);
    }

    public function msc_record(){
        $data = CounsellingData::where(['course_type'=>'PG','course_name'=>'MSC'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.MSC.record',['data'=>$data]);
    }

    public function mtech_record(){
        $data = CounsellingData::where(['course_type'=>'PG','course_name'=>'MTECH'])->orderBy('id','desc')->paginate(5);
        return view('admin.pages.MTECH.record',['data'=>$data]);
    }

    public function create(){
        return view('admin.pages.create_record');
    }

    public function status_update(Request $request, $id){
        $data = CounsellingData::find($id);
        if($data != ''){
            if($request['activated'] == '1'){
                $data->update(['activated'=>'1']);
                return redirect('BA');
            }else{
                $data->update(['activated'=>'0']);
                return redirect('BA');
            }
        }
    }   

    public function edit($id){
        $data = CounsellingData::find($id);
        if($data != ''){
            return view('admin.pages.update_record',['data'=>$data]);
        }
    }

    public function store(Request $request){

        $validation = Validator::make($request->all(),[
            'course_type'=>'required|in:UG,PG',
            'course_name'=>'required|in:BA,BCOM,BSC,BTECH,BALLB,BBA,BCA,BE,MA,MCOM,MSC,MTECH,MBA,MCA,LLBHONOURS',
            'tenth'=>'required',

            'twelth'=>'required',

            'income'=>'required',

            'caste'=>'required',

            'domicile'=>'required',

            'adhar'=>'required',

            'sssm'=>'required',
            'email'=>'required',

            'contact_no'=>'required',
            'hitgrahi'=>'required',

            'scholar_type'=>'required',
        ]);
 
        if($validation->fails()){
            return back()->withErrors($validation->errors());
        }
 
        if($request->hasFile('tenth_photo')) {
            $file = $request->file('tenth_photo');
            $tenth = $file->getClientOriginalName();
            $destinationPath = public_path().'/Tenth';
            $file->move($destinationPath,$tenth);
       }else{
           $tenth = '';
       }

       if($request->hasFile('twelth_photo')) {
           $file = $request->file('twelth_photo');
           $twelth = $file->getClientOriginalName();
           $destinationPath = public_path().'/Twelth';
           $file->move($destinationPath,$twelth);
       }else{
           $twelth = '';
       }

       if($request->hasFile('income_photo')) {
           $file = $request->file('income_photo');
           $income = $file->getClientOriginalName();
           $destinationPath = public_path().'/Income';
           $file->move($destinationPath,$income);
      }else{
       $income = '';
      }

       if($request->hasFile('caste_photo')) {
          $file = $request->file('caste_photo');
          $caste = $file->getClientOriginalName();
          $destinationPath = public_path().'/Caste';
          $file->move($destinationPath,$caste);
       }else{
           $caste = '';
       }

       if($request->hasFile('adhar_photo')) {
           $file = $request->file('adhar_photo');
           $aadhar = $file->getClientOriginalName();
           $destinationPath = public_path().'/Aadhar';
           $file->move($destinationPath,$aadhar);
       }else{
           $aadhar = '';
       }

       if($request->hasFile('domicile_photo')) {
           $file = $request->file('domicile_photo');
           $domicile = $file->getClientOriginalName();
           $destinationPath = public_path().'/Domicile';
           $file->move($destinationPath,$domicile);
       }else{
           $domicile = '';
       }

       if($request->hasFile('passport_size_photo')) {
           $file = $request->file('passport_size_photo');
           $passport_size = $file->getClientOriginalName();
           $destinationPath = public_path().'/PassportSizePhoto';
           $file->move($destinationPath,$passport_size);
       }else{
           $passport_size = '';
       }

       if($request->hasFile('hitgrahi_photo')) {
           $file = $request->file('hitgrahi_photo');
           $hitgrahi = $file->getClientOriginalName();
           $destinationPath = public_path().'/Hitgrahi';
           $file->move($destinationPath,$hitgrahi);
       }else{
           $hitgrahi = '';
       }

       if($request->hasFile('graduation_photo')) {
           $file = $request->file('graduation_photo');
           $Graduation = $file->getClientOriginalName();
           $destinationPath = public_path().'/Graduation';
           $file->move($destinationPath,$Graduation);
       }else{
           $Graduation = '';
       }
        
        CounsellingData::create([
            'course_type'=>$request['course_type'],
            'course_name'=>$request['course_name'],

            'tenth'=>$request['tenth'],
            'tenth_photo'=>$tenth,

            'twelth'=>$request['twelth'],
            'twelth_photo'=>$twelth,

            'income'=>$request['income'],
            'income_photo'=>$income,

            'caste'=>$request['caste'],
            'caste_photo'=>$caste,

            'adhar'=>$request['adhar'],
            'adhar_photo'=>$aadhar,

            'domicile'=>$request['domicile'],
            'domicile_photo'=>$domicile,
            'passport_size_photo'=>$passport_size,

            'sssm'=>$request['sssm'],

            'email'=>$request['email'],
            'contact_no'=>$request['contact_no'],

            'hitgrahi'=>$request['hitgrahi'],
            'hitgrahi_photo'=>$hitgrahi,

            'activated'=>1,
            'scholar_type'=>$request['scholar_type'],
            'graduation'=>$request['graduation'],
            'graduation_photo'=>$Graduation
         ]);
 
        return back()->with('status',"Records Inserted Successfully");
    } 

    public function update(Request $request, $id){

        $validation = Validator::make($request->all(),[
            'course_type'=>'required|in:UG,PG',
            'course_name'=>'required|in:BA,BCOM,BSC,BTECH,BALLB,BBA,BCA,BE,MA,MCOM,MSC,MTECH,MBA,MCA,LLBHONOURS',
            'tenth'=>'required',

            'twelth'=>'required',

            'income'=>'required',

            'caste'=>'required',

            'domicile'=>'required',

            'adhar'=>'required',

            'sssm'=>'required',
            'email'=>'required',

            'contact_no'=>'required',
            'hitgrahi'=>'required',

            'scholar_type'=>'required',
        ]);
 
        if($validation->fails()){
            return back()->withErrors($validation->errors());
        }
 
        if($request->hasFile('tenth_photo')) {
             $file = $request->file('tenth_photo');
             $tenth = $file->getClientOriginalName();
             $destinationPath = public_path().'/Tenth';
             $file->move($destinationPath,$tenth);
        }else{
            $tenth = '';
        }

        if($request->hasFile('twelth_photo')) {
            $file = $request->file('twelth_photo');
            $twelth = $file->getClientOriginalName();
            $destinationPath = public_path().'/Twelth';
            $file->move($destinationPath,$twelth);
        }else{
            $twelth = '';
        }

        if($request->hasFile('income_photo')) {
            $file = $request->file('income_photo');
            $income = $file->getClientOriginalName();
            $destinationPath = public_path().'/Income';
            $file->move($destinationPath,$income);
       }else{
        $income = '';
       }

        if($request->hasFile('caste_photo')) {
           $file = $request->file('caste_photo');
           $caste = $file->getClientOriginalName();
           $destinationPath = public_path().'/Caste';
           $file->move($destinationPath,$caste);
        }else{
            $caste = '';
        }

        if($request->hasFile('adhar_photo')) {
            $file = $request->file('adhar_photo');
            $aadhar = $file->getClientOriginalName();
            $destinationPath = public_path().'/Aadhar';
            $file->move($destinationPath,$aadhar);
        }else{
            $aadhar = '';
        }

        if($request->hasFile('domicile_photo')) {
            $file = $request->file('domicile_photo');
            $domicile = $file->getClientOriginalName();
            $destinationPath = public_path().'/Domicile';
            $file->move($destinationPath,$domicile);
        }else{
            $domicile = '';
        }

        if($request->hasFile('passport_size_photo')) {
            $file = $request->file('passport_size_photo');
            $passport_size = $file->getClientOriginalName();
            $destinationPath = public_path().'/PassportSizePhoto';
            $file->move($destinationPath,$passport_size);
        }else{
            $passport_size = '';
        }

        if($request->hasFile('hitgrahi_photo')) {
            $file = $request->file('hitgrahi_photo');
            $hitgrahi = $file->getClientOriginalName();
            $destinationPath = public_path().'/Hitgrahi';
            $file->move($destinationPath,$hitgrahi);
        }else{
            $hitgrahi = '';
        }

        if($request->hasFile('graduation_photo')) {
            $file = $request->file('graduation_photo');
            $Graduation = $file->getClientOriginalName();
            $destinationPath = public_path().'/Graduation';
            $file->move($destinationPath,$Graduation);
        }else{
            $Graduation = '';
        }
        
        CounsellingData::where(['id'=>$id])->update([
            'course_type'=>$request['course_type'],
            'course_name'=>$request['course_name'],

            'tenth'=>$request['tenth'],
            'tenth_photo'=>$tenth,

            'twelth'=>$request['twelth'],
            'twelth_photo'=>$twelth,

            'income'=>$request['income'],
            'income_photo'=>$income,

            'caste'=>$request['caste'],
            'caste_photo'=>$caste,

            'adhar'=>$request['adhar'],
            'adhar_photo'=>$aadhar,

            'domicile'=>$request['domicile'],
            'domicile_photo'=>$domicile,
            'passport_size_photo'=>$passport_size,

            'sssm'=>$request['sssm'],

            'email'=>$request['email'],
            'contact_no'=>$request['contact_no'],

            'hitgrahi'=>$request['hitgrahi'],
            'hitgrahi_photo'=>$hitgrahi,

            'activated'=>1,
            'scholar_type'=>$request['scholar_type'],
            'graduation'=>$request['graduation'],
            'graduation_photo'=>$Graduation
         ]);
 
        return back()->with('status',"Records Updated Successfully");
    } 

    public function delete($id){
        $data = CounsellingData::where(['id'=>$id])->delete();
        return back()->with('success','Record Deleted Successfully');
    }


    public function collage_record(){
        $data = Collage::all();
        return view('admin.pages.Collage.collage_list', compact('data'));
    }
    
    public function collage_record_create(){
        return view('admin.pages.Collage.collage_form');
    }

}

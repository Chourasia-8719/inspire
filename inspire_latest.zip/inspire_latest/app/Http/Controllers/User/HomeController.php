<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Validator,Hash,Auth};
use App\Models\{Contact,User,Newsletter};

class HomeController extends Controller
{
    public function index(){
        return view('user.home');
    }
    
    public function newsletter_store(Request $request){
        Newsletter::create([
            'email'=>$request['email'],
            'activated'=>'1'
        ]);
        return back()->with('success',"Thanks For SUbscribing Newsletter");
    }

    public function about_us(){
        return view('user.about');
    }
 
    public function courses(){
        return view('user.courses');
    }
 
    public function contact_us(){
        return view('user.contact');
    }
    
        //////////////// Contact Form Submission ////////////////////
    
    public function store(Request $request){

        $validation = Validator::make($request->all(),[
            'name' =>'required|string|max:30',
            'email' =>'required|string',
            'message'=> 'required|string|max:100',
            'subject'=>'required|string|max:30'
        ]);

        if($validation->fails()){
            return back()->withErrors($validation->errors());
        }
    
        Contact::create([
            'name'=>$request['name'],
            'email'=>$request['email'],
            'subject'=>$request['subject'],
            'message'=>$request['message'],
        ]);

        return back()->with('success','Thanks for Sharing Details');
    }
        //////////////// Contact Form Submission ////////////////////

        //////////////// Login View ////////////////////

    public function login(){
        return view('auth.login');
    }

        //////////////// Login View ////////////////////

            //////////////// Login Form Submission ////////////////////

     public function login_store(Request $request){
        $validation = Validator::make($request->all(),[
            'email'=> 'required|email',
            'password'=>'required|min:3'
        ]);
 
        if($validation->fails()){
            return back()->withErrors($validation->errors());
        }

        $credentials = $request->only('email', 'password');

         if(Auth::attempt($credentials)){
            if(Auth::user()->activated == '1' && Auth::user()->type == 'admin'){
                return redirect('/dashboard')->with('success','Admin Logged In');
            }
            if(Auth::user()->activated == '1'){
                return redirect('/dashboard')->with('success','Admin Logged In');
            }else{
                return back()->with('error',"Please Wait Once admin Approves your Account");
            }
         }else{
            return back()->with('error',"Invalid Credentials");
         }
     }

             //////////////// Login Form Submission ////////////////////


     public function register(){
        return view('auth.register');
    }

    //////////////// Register Form Submission ////////////////////

    public function register_store(Request $request){
        
        $validation = Validator::make($request->all(),[
            'firstname' =>'required|string',
            'lastname' =>'required|string',
            'email'=> 'required|email|unique:users',
            'password'=>'required|min:3'
        ]);
 
        if($validation->fails()){
            return back()->withErrors($validation->errors());
        }
       
        User::create([
            'firstname'=>$request['firstname'],
            'lastname'=>$request['lastname'],
            'email'=>$request['email'],
            'password'=>Hash::make($request['password']),
            'activated'=>'1',
            'type'=>'user'
        ]);

        return redirect("login")->with('status','Great! You have Successfully Registered');
    }

         //////////////// Register Form Submission ////////////////////

        //////////////// Student Form Submission ////////////////////

    public function student_store(Request $request){
       
        User::create([
            'firstname'=>$request['firstname'],
            'lastname'=>$request['lastname'],
            'email'=>$request['email'],
            'phone'=>$request['phone'],
            'message'=>$request['message'],
            'activated'=>'0'
        ]);
            
        //////////////// Student Form Submission ////////////////////

        return back()->with('success','Great! You have Successfully Register');
    }
}
